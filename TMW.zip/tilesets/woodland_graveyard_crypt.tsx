<?xml version="1.0" encoding="UTF-8"?>
<tileset name="woodland_graveyard_crypt" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/woodland_graveyard_crypt.png" width="224" height="288"/>
</tileset>
