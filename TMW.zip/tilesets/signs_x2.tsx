<?xml version="1.0" encoding="UTF-8"?>
<tileset name="signs_x2" tilewidth="32" tileheight="64">
 <image source="../graphics/sprites/npcs/signs.png" width="256" height="192"/>
</tileset>
