<?xml version="1.0" encoding="UTF-8"?>
<tileset name="signs" tilewidth="32" tileheight="32">
 <image source="../graphics/sprites/npcs/signs.png" width="256" height="192"/>
</tileset>
