<?xml version="1.0" encoding="UTF-8"?>
<tileset name="desert_castle2" tilewidth="32" tileheight="32">
 <image source="../graphics/tiles/desert_castle2.png" width="512" height="512"/>
</tileset>
