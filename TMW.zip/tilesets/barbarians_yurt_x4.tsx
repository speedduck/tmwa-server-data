<?xml version="1.0" encoding="UTF-8"?>
<tileset name="barbarians_yurt_x4" tilewidth="160" tileheight="128">
 <image source="../graphics/tiles/barbarians_yurt_x4.png" width="320" height="128"/>
</tileset>
