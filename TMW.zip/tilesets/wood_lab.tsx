<?xml version="1.0" encoding="UTF-8"?>
<tileset name="wood_lab" tilewidth="96" tileheight="96">
 <image source="../graphics/tiles/wood_lab.png" width="384" height="288"/>
 <tile id="8">
  <properties>
   <property name="animation-delay0" value="5"/>
   <property name="animation-delay1" value="5"/>
   <property name="animation-delay2" value="5"/>
   <property name="animation-delay3" value="5"/>
   <property name="animation-delay4" value="5"/>
   <property name="animation-delay5" value="5"/>
   <property name="animation-delay6" value="5"/>
   <property name="animation-delay7" value="5"/>
   <property name="animation-frame0" value="1"/>
   <property name="animation-frame1" value="2"/>
   <property name="animation-frame2" value="3"/>
   <property name="animation-frame3" value="4"/>
   <property name="animation-frame4" value="5"/>
   <property name="animation-frame5" value="6"/>
   <property name="animation-frame6" value="7"/>
   <property name="animation-frame7" value="0"/>
  </properties>
 </tile>
</tileset>
