<?xml version="1.0" encoding="UTF-8"?>
<tileset name="crypt_x5" tilewidth="32" tileheight="160">
 <image source="../graphics/tiles/crypt_x5.png" width="512" height="160"/>
</tileset>
